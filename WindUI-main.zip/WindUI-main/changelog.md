# 1.6.63
## Changelog:
- Fixed Tag text color